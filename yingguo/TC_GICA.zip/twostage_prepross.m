
% orginal data are JK-by-I (I: number of time points.  J: number of voxels.
% K: number of subjects)

function  [prep]=twostage_prepross(data_2Dall,I,J,K,subj_PCA_R,q)


  
%-------------  2. pre-processing  ----------------
 % PCA dimension reduction 

 % change data dimension to T-by-NV
 if (size(data_2Dall,1)/K==I && size(data_2Dall,2)==J)   % if data2D is TN-by-V
 
X_normed=data_2Dall;
 
 clear data;
for i=1:K
 if i==1
   data=X_normed((i-1)*I+1:i*I,:); 
 else
   data=[data X_normed((i-1)*I+1:i*I,:)]; 
 end
end

 elseif  (size(data_2Dall,1)/K==J && size(data_2Dall,2)==I)    % if the data2D is VN-by-T
 data=data_2Dall';
 
 elseif  (size(data_2Dall,2)/K==J && size(data_2Dall,1)==I)  % if data2D is T-by-VN
  data=data_2Dall;
  
 elseif   (size(data_2Dall,2)/K==I && size(data_2Dall,1)==J)  % if data2D is V-by-TN
     for i=1:K
     if i==1
     data=X_normed(:,(i-1)*I+1:i*I)'; 
     else
     data=[data X_normed(:,(i-1)*I+1:i*I)']; 
     end
     end
 else 
     disp('check the dimension of the input data ')
 end 
% remove the  mean for PCA
[data,mixedmean]=remmean(data);

[U1 D1]=svd(data,0);
U_R=U1(:,1:subj_PCA_R);
clear U1 D1;


%[U_incr, D_incr]=pcamat(data);
%lambda=sort(diag(D_incr),'descend');  % sort the eig values, IX:index
%plot(1:100,lambda(1:100));

  clear X_tilde_all X_tilde data_subj;
 
   for i=1:K
    data_subj=data(:,(i-1)*J+1:i*J);
   X_tilde=U_R'*data_subj;
    if i==1
      X_tilde_all=X_tilde;
    else
      X_tilde_all=[X_tilde_all; X_tilde];
    end
   end;
   clear X_tilde data_subj;
 
% 11/30/06  my own whitening matrix-- uses pcamat for PCA, the same results as using svd
% in tensorICA
[X_tilde_all,mixedmean]=remmean(X_tilde_all);
[U_incr, D_incr]=pcamat(X_tilde_all);

lambda=sort(diag(D_incr),'descend');  % sort the eig values, IX:index
%plot(1:100,lambda(1:50));

    % dim reduction based on the scree plot
  U_q=U_incr(:,size(U_incr,2)-q+1:size(U_incr,2));
  D_q=diag(D_incr(size(U_incr,2)-q+1:size(U_incr,2),size(U_incr,2)-q+1:size(U_incr,2)));
 
  sigma2_ML=sum(lambda(q+1:length(lambda)))/(length(lambda)-q);
    
%define my own whitening, dewhitening matrix and whitened data;
  my_whiteningMatrix=diag((D_q-sigma2_ML).^(-1/2))*U_q';
  my_dewhiteningMatrix=U_q*diag((D_q-sigma2_ML).^(1/2));
  my_whitesig= my_whiteningMatrix*X_tilde_all;

 
% overall two-stage dim reduc and whitening transformation matrix 

for K_i=1:K
if K_i==1
blkdig_mtx=U_R';
else
blkdig_mtx=blkdiag(blkdig_mtx,U_R');
end
end 
H_matrix=my_whiteningMatrix*blkdig_mtx; % transform matrix for the two-stage dim reduc and whitening;

prep.U_R=U_R;
prep.my_dewhite_all=my_dewhiteningMatrix;
prep.my_white_all=my_whiteningMatrix;
prep.U_q_all=U_q;
prep.my_whitesig=my_whitesig;
prep.H_matrix=H_matrix;
prep. X_tilde_all= X_tilde_all;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~  end of I. prepare data

