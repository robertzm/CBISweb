%=========================================================================
%  Exact EM algorithm for fitting group PICA model 
% 
%    written by Ying Guo, Emory University
%
% Reference: Guo Y (2011). A general probabilistic model for group independent
%  component analysis and its estimation methods. Biometrics.  67(4): 1532-1542.
%=========================================================================

% =========inputs: 
% 1. data_2Dall:   QK-by-V group data concartenated on the temporal domain
%    (Q: # of fMRI scans/time points; K:# of subjects; V:# of voxels
% 2. M_guess: inital guess for the group mixing matrix (TK-by-q matrix)
% 3. parm_def: parameters
%      parm_def.q: number of ICs to extract
%      parm_def.m: number of Guassian components in MOG, currently m=2 but the program can be modified for m>2;
%      parm_def.V: number of voxels 
%      parm_def.K: number of subjects
%      parm_def.subj_PCA_R: number of PCs to retain within subject in the first stage of
%                           the two-stage dimension reduction procedure
% 4. model_ind: specifies the type of group structure in the mixing matrix
%     =1: subject-specific structure
%     =2: multi-group tensor structure; 
%     =3: single-group tensor structure
% 5. epsilon: stopping rule for iterations, stopes if the parameter
%    estimates between the two iterations has a difference < epsilon
% 6. maxiter: maximum iteration numbers 
%
% =========Outputs: 
% 1.  theta_est 
%     theta_est(1:dim(1)):  mixing matrix    A_est=reshape(theta_est(1:dim(1)),[T q]); 
%     theta_est(dim(1)+1:sum(dim(1:2))): Gaussian residual variance in PICA
%     theta_est(sum(dim(1:3))+1:sum(dim(1:4))): pi in the MoG source distribution model
%                                               pi_est=reshape(theta_est(sum(dim(1:3))+1:sum(dim(1:4))),[m q])';
%     theta_est(sum(dim(1:4))+1:sum(dim(1:5))): mu in the MoG source distribution model
%                                               mu_est=reshape(theta_est(sum(dim(1:4))+1:sum(dim(1:5))),[m q])';
%     theta_est(sum(dim(1:5))+1:sum(dim(1:6))): variance in the MoG source distribution model
%                                               sig2mog_est=reshape(theta_est(sum(dim(1:5))+1:sum(dim(1:6))),[m q])';
% 2.  H :  the transform matrix for the two-stage dim reduction and whitening
% 3.  s_bar_est: estimated spatial source signals
% 4.  var_s_est: estimated variance for the source signals
% 5.  p_r_est: P(z_r|data)  the posterior probabilies of the latent states
%                           variables of the MoG.
% 6.  A_tilde_tensor:      the tensor time serious for the single-group and
%                          multigroup tensor structures
% 7.  C_tensor: the subject loadings in the single-group and
%                          multigroup tensor structures
% 8.  conv:  convergence indicator (=1: converged  =0: not converged)  
%==========================================================================

function  [theta_est,H,s_bar_est,var_s_est,p_r_est,A_tilde_tensor,C_tensor,conv]=TC_GICA_EM_exact...
    (data_2Dall,M_guess,parm_def, model_ind,epsilon,maxiter)
 
  T=parm_def.q; % for whitened data, T=q, square matrix;
  q=parm_def.q;
  m=parm_def.m;
  V=parm_def.V;
  subj_PCA_R=parm_def.subj_PCA_R;
  K=parm_def.K;
  I=size(data_2Dall)/K;  % number of time points
  
  dim(1)=T*q;  % dim of the mixing matrix
  dim(2)=1;    % dim of sigma2 for guassian residual in the PICA model
  dim(3)=0;   % dim for corr rho,  dim(3)=1 for toepliz correlation and 0 for indentity corr
  dim(4)=(m-1)*q; % dim for pi in the MoG source distribution model
  dim(5)=m*q;     % dim for mu in the MoG source distribution model
  dim(6)=m*q;     % dim for variance in the MoG source distribution model
  
  %--------I. two-stage dimension reduction and whitening procedure-------
 
  prep=twostage_prepross.m(data_2Dall,I,V,K,subj_PCA_R,q)
  
  H=double(prep.H_matrix); % H is the transform matrix for the two-stage dim reduction and whitening
  my_dewhitemat=double(prep.my_dewhite_all);
  my_whitemat=double(prep.my_white_all);
  data=double(prep.my_whitesig);
  
  C_inv=inv(H*H');  
  
  
  
 %--------II. generate all possbile mixture combinitions for MOG----
clear jr r_resid;
for r=1:m^q
     r_resid=r-1;
  for kk=1:q
     jr(r,kk)=floor(r_resid/m^(q-kk));
    r_resid=r_resid-jr(r,kk)*m^(q-kk);
  end
end    
jr=jr+1;
  

%--------III. set the initial values----

A_guess=H*M_guess;
p_guess=0.1;  

theta_guess=[reshape(A_guess,[T*q 1]);0.1;repmat([0.9;0.1],[q 1]);repmat([-0.1;3],[q 1]);...
repmat([0.25;0.5],[q 1])]; 
 
%------- IV. Start the estimation -----
 iter=1;
 stopiter=0;
 
 
 
while stopiter==0
 clear theta_new g s_bar_old var_s_old p_r_old;
 
   if iter==1
       theta_old=theta_guess;
       
    A_old=reshape(theta_old(1:dim(1)),[T q]);    
  % projection 
    if (model_ind==2 || model_ind==3)
   [A_tilde_tensor,C_tensor,A_proj]=A_project(model_ind,A_old);
   A_old=A_proj;
    end
    
 % Symmetric orthogonalization. 
    A_old= A_old* real(inv(A_old' * A_old)^(1/2));
   
    theta_old(1:dim(1))=reshape(A_old,[T*q 1]);         
   end
   
  fprintf('iteration %6.0f  \n', iter);  
  
    [theta_new,g,s_bar_old,var_s_old,p_r_old]=EM_step(theta_old);
    

  if (norm(theta_new-theta_old)/q<epsilon || iter>maxiter)
   theta_est=theta_new;
   s_bar_est=s_bar_old;
   var_s_est=var_s_old;
   p_r_est=p_r_old;
   
   A_new=reshape(theta_new(1:dim(1)),[T q]);
   
   if model_ind==1
       A_tilde_tensor=0;
       C_tensor=0;
       
   else 
       [A_tilde_tensor,C_tensor,A_proj]=A_project(model_ind,A_new);
   end
   
  
   
   % change stop indictor when converges or exceeds max iter
   stopiter=1;
   
   % if it is stopped due to convergence, conv=1; otherwise, conv=0;
   if (norm(theta_new-theta_old)/q<epsilon)
   conv=1;
   else 
   conv=0;
   end
   
   
 else  % if not converge and below max iter
   fprintf('iteration %6.0f   and the difference is  %6.6f \n', iter, norm(theta_new-theta_old));  
 
   theta_old=theta_new;
   clear theta_new;
   iter=iter+1; 
   
 
 end   % end for if   
    
end %end for while   
   
     function [theta_new,g,s_bar_old,var_s_old,p_r_old]=EM_step(theta_old)
         
 %**************************************************
 % read parameter estimates from last iter 
 % **************************************************
  A_old=reshape(theta_old(1:dim(1)),[T q]);
  sig2_vox_old=theta_old(dim(1)+1:sum(dim(1:2)));                  
  
    
  
  my_pi_old=reshape(theta_old(sum(dim(1:3))+1:sum(dim(1:4))),[m q])';
  mu_old=reshape(theta_old(sum(dim(1:4))+1:sum(dim(1:5))),[m q])';
  sig2_old=reshape(theta_old(sum(dim(1:5))+1:sum(dim(1:6))),[m q])';  

   
   
 %**************************************************
 %  % the conditional distributions: 
 %   p(z_r|x,theta_old) and gaussian p(s|z_r,x,theta_old)    
 % **************************************************          
   
 clear p_r_old alpha_old Sigma_old;
 for r=1:m^q
  mu_r_old=diag(mu_old(:,jr(r,:))); % mu_r_old:  q-by-1 vector   mu^(r)
  sig2_r_old=diag(sig2_old(:,jr(r,:))); % sig2_r_old:  q-by-1 vector   sig2^(r)
  mypi_r_old=diag(my_pi_old(:,jr(r,:))); % mypi_r_old:  q-by-1 vector   pi^(r)

  row_T=size(data,1);  % number of row of the response variable x in ICA
  
  Sigma_inv_old_temp=A_old'*C_inv*A_old/sig2_vox_old+diag(1./sig2_r_old);  % 
  Sigma_old(:,:,r)=inv(Sigma_inv_old_temp);                          
  
  for vv=1:V
    g(r,vv)=mvnpdf(data(:,vv)',(A_old*mu_r_old)',A_old*diag(sig2_r_old)*A_old'+sig2_vox_old*H*H');  
    alpha_old(:,r,vv)=Sigma_old(:,:,r)*(A_old'*C_inv*data(:,vv)/sig2_vox_old+mu_r_old./sig2_r_old); 
  end   % end for vv=
   g(r,:)=prod(mypi_r_old)*g(r,:);
   
 end   % end for r= 
  p_r_old=g./(repmat(sum(g,1),[size(g,1),1]));  % divide by the sum across r to obtain P(z_r|x)
   
       
 %**********************************************************************
 % cacluate mean and variance of the posterior mixture gaussian
 % Pr(s|x,theta_old)=sum(p_r_old*p(s|z_r,x,theta_old)); 
 % the posterior mean and variance of s 
 %**********************************************************************
 
 clear s_bar_old var_s_old wt_sec_m_r wt_fst_m_r post_sec_m temp2;
 wt_sec_m_r=zeros(q,m^q,V); % E(s^2|z_r,x,theta_old) 
 wt_fst_m_r=zeros(q,m^q,V); % E(s|z_r,x,theta_old)
 post_sec_m=zeros(q,q,V); % E(ss'|x,theta_old) sumed across r
 temp2=zeros(size(data,1),q); % sum_v {xs'}
  
 for vv=1:V
    wt_fst_m_r(:,:,vv)=alpha_old(:,:,vv)*diag(p_r_old(:,vv));  
    s_bar_old(:,vv)=sum(wt_fst_m_r(:,:,vv),2); % sum across r
    temp2=temp2+data(:,vv)*s_bar_old(:,vv)';
    
    for r=1:m^q
    temp_sec_m=p_r_old(r,vv)*(Sigma_old(:,:,r)+alpha_old(:,r,vv)*alpha_old(:,r,vv)');  
    post_sec_m(:,:,vv)=post_sec_m(:,:,vv)+temp_sec_m;
    wt_sec_m_r(:,r,vv)=diag(temp_sec_m);
     
     end

    var_s_old(:,:,vv)=post_sec_m(:,:,vv)-s_bar_old(:,vv)*s_bar_old(:,vv)';
 end 

   
%**********************************************************************
% update for  A_new and sig2_vox_new
%**********************************************************************
   
theta_new=zeros(sum(dim),1)./zeros(sum(dim),1);

%************** updated estimate for A ******************  
   A_new=temp2*inv(sum(post_sec_m,3));
  
% projection 
    if (model_ind==2 || model_ind==3)
   [A_tilde_tensor,C_tensor,A_new_proj]=A_project(model_ind,A_new);
   A_new=A_new_proj;
    end
    
 % Symmetric orthogonalization. not needed with scaling
    A_new= A_new* real(inv(A_new' * A_new)^(1/2));
   
theta_new(1:dim(1))=reshape(A_new,[T*q 1]);    
  
  
  %*********** update estimate for sig2_vox ***************
 sig2_vox_new=0;

 for vv=1:V
 sig2_vox_new=sig2_vox_new+data(:,vv)'*C_inv*data(:,vv)-2*data(:,vv)'*C_inv*A_new*s_bar_old(:,vv);
 end
 sig2_vox_new=(sig2_vox_new+trace(A_new'*C_inv*A_new*sum(post_sec_m,3)))/(size(data,1)*V); 
 
% update parameter vector 
 theta_new(dim(1)+1:sum(dim(1:2)))=sig2_vox_new; 
  
 
  
%**********************************************************************
% update for  parameters in mixture guassian distributions
%**********************************************************************      


[my_pi_new,mu_new,sig2_new]=sum_z_r(p_r_old,wt_fst_m_r,wt_sec_m_r);


theta_new((sum(dim(1:3))+1):sum(dim(1:4)))=reshape(my_pi_new',[m*q 1]);
theta_new((sum(dim(1:4))+1):sum(dim(1:5)))=reshape(mu_new',[m*q 1]);
theta_new((sum(dim(1:5))+1):sum(dim(1:6)))=reshape(sig2_new',[m*q 1]);


     end  % end for function EM-step


         function [my_pi,mu,sig2]=sum_z_r(p_r,wt_fst_m_r,wt_sec_m_r)
             
             for l=1:q
               for j=1:m
                   
                   %------ calculate the subset z_r for s.t. z_l=j
                   z_r_idx=0;
                   for kk=1:m^(l-1)
                   z_r_idx=[z_r_idx m^(q-l+1)*(kk-1)+((m^(q-l)*(j-1)+1):(m^(q-l)*j))];
                   end % end for kk
                   z_r_idx=z_r_idx(2:length(z_r_idx));
                   
                   p_r_lj=p_r(z_r_idx,:);
                   wt_fst_m_r_lj=wt_fst_m_r(:,z_r_idx,:);
                   wt_sec_m_r_lj=wt_sec_m_r(:,z_r_idx,:);
                   
                   my_pi(l,j)=sum(sum(p_r_lj))/V;
                   mu(l,j)=sum(sum(wt_fst_m_r_lj(l,:,:),2),3)/(my_pi(l,j)*V);
                   sig2(l,j)=sum(sum(wt_sec_m_r_lj(l,:,:),2),3)/(my_pi(l,j)*V)-mu(l,j)^2;
               end % end for j    
             end  % end for l    
             
         end  % end for function sum_z_r    





      
      function  [A_tilde_tensor,C_tensor,A_proj]=A_project(model_ind,A_old)
    
       %------- for tensor 1 model   
   if model_ind==3  
      % de-whiting w to the original space and then perform the rank-1 approx.

   clear U_tensor D_tensor V_tensor A_dewht M_r A_tilde_tensor C_tensor;
   A_dewht=my_dewhitemat * A_old;
   for round=1:size(A_dewht,2)
      M_r=reshape(A_dewht(:,round),[subj_PCA_R K]);
      [U_tensor,D_tensor,V_tensor]=svd(M_r,0);
      A_tilde_tensor(:,round)=U_tensor(:,1);
      C_tensor(:,round)=V_tensor(:,1);
      
      A_dewht(:,round)=kron(C_tensor(:,round),A_tilde_tensor(:,round))*D_tensor(1,1);
   end   % for round=
     A_proj=my_whitemat*A_dewht;
  end  % end for if model_ind==3
  
  
     %------- for tensor 2 model   
   if model_ind==2  
      % de-whiting w to the original space and then perform the rank-2 approx.

   clear U_tensor D_tensor V_tensor A_dewht M_r A_tilde_tensor C_tensor;
   A_dewht=my_dewhitemat * A_old;
   for round=1:size(A_dewht,2)
      M_r=reshape(A_dewht(:,round),[subj_PCA_R K]);
      [U_tensor,D_tensor,V_tensor]=svd(M_r,0);
      A_tilde_tensor(:,:,round)=U_tensor(:,1:2);
      C_tensor(:,:,round)=V_tensor(:,1:2);
      
      A_dewht(:,round)=kron(C_tensor(:,1,round),A_tilde_tensor(:,1,round))*D_tensor(1,1)+...
                       kron(C_tensor(:,2,round),A_tilde_tensor(:,2,round))*D_tensor(2,2);
   end   % for round=
     A_proj=my_whitemat*A_dewht;
  end  % end for if model_ind==3
  
    
   
end  % function projection  
      
      
      
    
end   % 
